// =======================html overflow hidden when small device nav show =================

let htmlTag = document.querySelector("html");
let barBtn = document.querySelector(".bar-icon");
let crossBtn = document.querySelector(".cross-iconBtn");

barBtn.addEventListener("click", function () {
  htmlTag.style.overflow = "hidden";
});

crossBtn.addEventListener("click", function () {
  htmlTag.style.overflow = "auto";
});

// ======================================hide navbar nav-end part============================

window.addEventListener("DOMContentLoaded", function () {
  // Function to toggle the display based on window width and scroll position
  function toggleNavEndDisplay() {
    const hideSection = document.querySelector(".nav-end");

    if (window.innerWidth > 900) {
      const scrollPosition = window.pageYOffset;

      if (scrollPosition >= 200) {
        hideSection.style.display = "none";
      } else {
        hideSection.style.display = "flex";
      }
    } else {
      hideSection.style.display = "none";
    }
  }

  // Initial call to set the display based on the window width and scroll position
  toggleNavEndDisplay();

  // Listen for scroll and window resize events to update the display
  window.addEventListener("scroll", toggleNavEndDisplay);
  window.addEventListener("resize", toggleNavEndDisplay);
});

// =============================nav small slighly down when page move down =================

const navbarSmall = document.querySelector(".navbar-sm .link-items");

window.addEventListener("scroll", () => {
  const scrollPosition = window.pageYOffset;
  if (window.innerWidth <= 576) {
    if (scrollPosition >= 100) {
      navbarSmall.style.top = "-1rem";
      navbarSmall.style.transition = `all 0s ease-in-out`;
    } else if (scrollPosition < 100) {
      navbarSmall.style.top = "-5.3rem";
      navbarSmall.style.transition = `all 0s ease-in-out`;
    }
  } else if (window.innerWidth > 576) {
    if (scrollPosition >= 100) {
      navbarSmall.style.transition = `all 0s ease-in-out`;
      navbarSmall.style.top = "-1rem";
    } else if (scrollPosition < 100) {
      navbarSmall.style.transition = `all 0s ease-in-out`;
      navbarSmall.style.top = "-4.3rem";
    }
  }
});
// =======================for small device======================
let sideMenue = document.querySelector(".link-items");
let crossIcon = document.querySelector(".cross-iconBtn");
let barIcon = document.querySelector(".bar-icon");

crossIcon.addEventListener("click", function () {
  sideMenue.style.display = `block`;
  sideMenue.style.transition = `all 0.5s ease-in-out`;
  sideMenue.style.transform = `translate(-120%)`;
});
barIcon.addEventListener("click", function () {
  sideMenue.style.transition = `all 0.5s ease-in-out`;
  sideMenue.style.transform = `translate(-0%)`;
  sideMenue.style.display = `block`;
});

$(document).ready(function () {
  $(".carousel").slick({
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    dots: true,
    arrows: true,
    prevArrow: $(".custom-prev-arrow"),
    nextArrow: $(".custom-next-arrow"),
  });
});

// =============================for small device======================
$(document).ready(function () {
  $(".carousel-sm").slick({
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    dots: true,
    arrows: true,
    prevArrow: $(".custom-prev-arrow-sm"),
    nextArrow: $(".custom-next-arrow-sm"),
  });
});

// ==========Cutomer Favorite part ==============

$(".casrousel12 ").slick({
  // dots: true,
  infinite: false,
  speed: 300,
  slidesToShow: 4,
  slidesToScroll: 4,
  responsive: [
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        // dots: false,
      },
    },
    // {
    //   breakpoint: 600,
    //   settings: {
    //     slidesToShow: 2,
    //     slidesToScroll: 2,
    //   },
    // },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
      },
    },
    // {
    //   breakpoint: 300,
    //   settings: {
    //     slidesToShow: 1,
    //     slidesToScroll: 1,
    //   },
    // },
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ],
});

$(".casrouselbs ").slick({
  // dots: true,
  infinite: false,
  speed: 300,
  slidesToShow: 2,
  slidesToScroll: 2,
  responsive: [
    {
      breakpoint: 500,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        infinite: true,
        // dots: false,
      },
    },
    // {
    //   breakpoint: 600,
    //   settings: {
    //     slidesToShow: 2,
    //     slidesToScroll: 2,
    //   },
    // },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        variableWidth: true,
        centerPadding: "10px",
      },
    },
    // {
    //   breakpoint: 300,
    //   settings: {
    //     slidesToShow: 1,
    //     slidesToScroll: 1,
    //     variableWidth: true,
    //   },
    // },
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ],
});

// ========================================navbar nav-end part=======================
const headingA = document.querySelector(".a-block-part");
const headingAH = document.querySelector(".heading-a-sb");
const headingAHSC = document.querySelector(".ct-menu .heading-a-sc");
const exp_a = document.querySelector(".exp-a ");
const exp_asb = document.querySelector(".exp-asb");
exp_a.addEventListener("mouseover", () => {
  headingA.style.display = "none";
  headingAH.style.backgroundColor = "white";
  headingAH.style.color = "black";
});

headingAH.addEventListener("mouseover", () => {
  headingA.style.display = "flex";
  headingAH.style.backgroundColor = "#94bd5b";
  headingAH.style.color = "white";
});

exp_asb.addEventListener("mouseover", () => {
  headingAHSC.style.backgroundColor = "white";
  headingAHSC.style.color = "black";
});

headingAHSC.addEventListener("mouseover", () => {
  headingAHSC.style.display = "flex";
  headingAHSC.style.backgroundColor = "#94bd5b";
  headingAHSC.style.color = "white";
});

// ========================================navbar nav-end part=======================
const footerDownSvg = document.querySelector(
  ".site-footer-block-menu .chevDownLeftRightSvg"
);
const lineSvgClose = document.querySelector(
  ".site-footer-block-menu .icon-minusCC"
);
const footerMenu = document.querySelector(".site-footer-block-menu .navmenuCC");

footerDownSvg.addEventListener("click", () => {
  footerMenu.style.display = "block";
  footerDownSvg.style.display = "none";
  lineSvgClose.style.display = "inline";
});

lineSvgClose.addEventListener("click", () => {
  footerMenu.style.display = "none";
  footerDownSvg.style.display = "block";
  lineSvgClose.style.display = "none";
});

//  console.log(footerDownSvg)
//  console.log(minusMeSvg)
// ============================================Top Selling part===============================
const footerDownSvgTp = document.querySelector(
  ".site-footer-block-menu .downTopSell"
);
const lineSvgCloseTp = document.querySelector(
  ".site-footer-block-menu .icon-minusTP"
);
const footerMenuTp = document.querySelector(
  ".site-footer-block-menu .navmenuTP"
);

footerDownSvgTp.addEventListener("click", () => {
  footerMenuTp.style.display = "block";
  footerDownSvgTp.style.display = "none";
  lineSvgCloseTp.style.display = "inline";
});

lineSvgCloseTp.addEventListener("click", () => {
  footerMenuTp.style.display = "none";
  footerDownSvgTp.style.display = "block";
  lineSvgCloseTp.style.display = "none";
});

// ===========================================Home Start Image move Text =================

{
  let textImgMove = document.querySelectorAll(
    ".slideshow-slide__content-background-link"
  );
  let prevBtn = document.querySelector(".custom-prev-arrow");
  let nextBtn = document.querySelector(".custom-next-arrow");
  let currentIndex = 0;

  prevBtn.addEventListener("click", function () {
    textImgMove[currentIndex].style.transform = "translateY(35px)";
    textImgMove[currentIndex].style.opacity = "0";
    const previousIndex =
      (currentIndex - 1 + textImgMove.length) % textImgMove.length;
    textImgMove[previousIndex].style.transform = "translateY(-35px)";
    textImgMove[previousIndex].style.opacity = "1";
    currentIndex = previousIndex;
  });

  nextBtn.addEventListener("click", function () {
    textImgMove[currentIndex].style.transform = "translateY(35px)";
    textImgMove[currentIndex].style.opacity = "0";
    const nextIndex = (currentIndex + 1) % textImgMove.length;
    textImgMove[nextIndex].style.transform = "translateY(-35px)";
    textImgMove[nextIndex].style.opacity = "1";
    currentIndex = nextIndex;
    // console.log("nextBtn",currentIndex)
  });
}

{
  let textImgMove = document.querySelectorAll(".slideshow-slide__button ");
  let prevBtn = document.querySelector(".custom-prev-arrow");
  let nextBtn = document.querySelector(".custom-next-arrow");
  let currentIndex = 0;

  prevBtn.addEventListener("click", function () {
    textImgMove[currentIndex].style.transform = "translateY(35px)";
    textImgMove[currentIndex].style.opacity = "0";
    const previousIndex =
      (currentIndex - 1 + textImgMove.length) % textImgMove.length;
    textImgMove[previousIndex].style.transform = "translateY(-35px)";
    textImgMove[previousIndex].style.opacity = "1";
    currentIndex = previousIndex;
  });

  nextBtn.addEventListener("click", function () {
    textImgMove[currentIndex].style.transform = "translateY(35px)";
    textImgMove[currentIndex].style.opacity = "0";
    const nextIndex = (currentIndex + 1) % textImgMove.length;
    textImgMove[nextIndex].style.transform = "translateY(-35px)";
    textImgMove[nextIndex].style.opacity = "1";
    currentIndex = nextIndex;
    // console.log("nextBtn",currentIndex)
  });
}
//============================================Home paragraph for maduim Device============================================

// ============================Small device navbar sub Menu=========================

// =========================Shop By brand part =======================
let smSBMenu = document.querySelector(".sm-link-sh-sub-part");
let smSBDownMBtn = document.querySelector(".navDwon-sb");
let smSBUPMBtn = document.querySelector(".navUp-sb");
smSBDownMBtn.addEventListener("click", function () {
  smSBMenu.style.display = "block";
  smSBDownMBtn.style.display = "none";
  smSBUPMBtn.style.display = "inline";
});
smSBUPMBtn.addEventListener("click", function () {
  smSBMenu.style.display = "none";
  smSBDownMBtn.style.display = "inline";
  smSBUPMBtn.style.display = "none";
});
// =========================Shop By Categries part =======================
let smSCMenu = document.querySelector(".sm-link-sc-sub-part");
let smSCDownMBtn = document.querySelector(".navDwon-sc");
let smSCUPMBtn = document.querySelector(".navUp-sc");
smSCDownMBtn.addEventListener("click", function () {
  smSCMenu.style.display = "block";
  smSCDownMBtn.style.display = "none";
  smSCUPMBtn.style.display = "inline";
});
smSCUPMBtn.addEventListener("click", function () {
  smSCMenu.style.display = "none";
  smSCDownMBtn.style.display = "inline";
  smSCUPMBtn.style.display = "none";
});
// =========================About us part =======================
let smABMenu = document.querySelector(".sm-link-ab-sub-part");
let smABDownMBtn = document.querySelector(".navDwon-ab");
let smABUPMBtn = document.querySelector(".navUp-ab");
smABDownMBtn.addEventListener("click", function () {
  smABMenu.style.display = "block";
  smABDownMBtn.style.display = "none";
  smABUPMBtn.style.display = "inline";
});
smABUPMBtn.addEventListener("click", function () {
  smABMenu.style.display = "none";
  smABDownMBtn.style.display = "inline";
  smABUPMBtn.style.display = "none";
});
// =========================customer service part =======================
let smCSMenu = document.querySelector(".sm-link-cs-sub-part");
let smCSDownMBtn = document.querySelector(".navDwon-cs");
let smCSUPMBtn = document.querySelector(".navUp-cs");
smCSDownMBtn.addEventListener("click", function () {
  smCSMenu.style.display = "block";
  smCSDownMBtn.style.display = "none";
  smCSUPMBtn.style.display = "inline";
});
smCSUPMBtn.addEventListener("click", function () {
  smCSMenu.style.display = "none";
  smCSDownMBtn.style.display = "inline";
  smCSUPMBtn.style.display = "none";
});
// =========================customer center us part =======================
let smCCMenu = document.querySelector(".sm-link-cc-sub-part");
let smCCDownMBtn = document.querySelector(".navDwon-cc");
let smCCUPMBtn = document.querySelector(".navUp-cc");
smCCDownMBtn.addEventListener("click", function () {
  smCCMenu.style.display = "block";
  smCCDownMBtn.style.display = "none";
  smCCUPMBtn.style.display = "inline";
});
smCCUPMBtn.addEventListener("click", function () {
  smCCMenu.style.display = "none";
  smCCDownMBtn.style.display = "inline";
  smCCUPMBtn.style.display = "none";
});
